package basechat;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class User2 extends JDialog {

    private final JPanel contentPanel = new JPanel();
    private JTextField userNameField;

    public static void main(String[] args) {
        try {
            LoginChat dialog = new LoginChat();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public User2() {
        setLocationByPlatform(true);
        setBounds(100, 100, 450, 114);
        getContentPane().setLayout(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        getContentPane().add(contentPanel, BorderLayout.CENTER);
        contentPanel.setLayout(null);
        {
            JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
            label.setBounds(10, 10, 54, 15);
            contentPanel.add(label);
        }

        userNameField = new JTextField();
        userNameField.setBounds(75, 7, 349, 21);
        contentPanel.add(userNameField);
        userNameField.setColumns(10);
        {
            JPanel buttonPane = new JPanel();
            buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
            getContentPane().add(buttonPane, BorderLayout.SOUTH);
            {
                JButton okButton = new JButton("确认");
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent actionevent) {
                        String txt = userNameField.getText();
                        if (txt == null || "".equals(txt)) {
                            JOptionPane.showMessageDialog(User2.this, "请输入用户名","提示",JOptionPane.WARNING_MESSAGE);
                            userNameField.requestFocus();
                            return;
                        }
                        EventQueue.invokeLater(new Runnable() {
                            public void run() {
                                try {
                                    Main frame = new Main(userNameField
                                            .getText());
                                    frame.setVisible(true);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        User2.this.dispose();
                    }
                });
                okButton.setActionCommand("确认");
                buttonPane.add(okButton);
                getRootPane().setDefaultButton(okButton);
            }
            {
                JButton cancelButton = new JButton("取消");
                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent actionevent) {
                        User2.this.dispose();
                    }
                });
                cancelButton.setActionCommand("取消");
                buttonPane.add(cancelButton);
            }
        }
    }
}
