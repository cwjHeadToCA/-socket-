package basechat;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class Server {
	private ServerSocket ss = null;
	private boolean isStarted = false;
	private Map<String,RecvThread> clients = new HashMap<String,Server.RecvThread>();

	public void start() {
		try {
			ss = new ServerSocket(8880);
			isStarted = true;
			System.out.println("服务器端开始工作");
		} catch (BindException e) {
			System.out.println("端口被占用，请关闭相关程序。");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		while (isStarted) {
			try {
				Socket s = ss.accept();
				RecvThread rt = new RecvThread(s);
				new Thread(rt).start();
			} catch (IOException e) {
				System.out.println(e.getMessage());
//				e.printStackTrace();
			}
		}
	}

	private class RecvThread implements Runnable {
		private Socket s = null;
		private ObjectInputStream ois = null;
		private ObjectOutputStream oos = null;
		private boolean isConnected = false;
		private String user;

		public RecvThread(Socket s) {
			this.s = s;
			try {
				ois = new ObjectInputStream(s.getInputStream());
				oos = new ObjectOutputStream(s.getOutputStream());
//				System.out.println("oos:" + oos);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			isConnected = true;
		}

		// 发送对象
		public void sendMsg(MsgInfo mi) {
			try {
				oos.writeObject(mi);
				oos.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// 转发消息给各客户端
		public void zfMsg(MsgInfo mi) {
			if (mi.isSL()) { // 私聊
				// 发给对方。
				// 根据用户名得到对方的RecvThread
				RecvThread rt = clients.get(mi.getUser());
				rt.sendMsg(mi);
				System.out.println("私聊");

			} else { // 群聊
				System.out.println("群聊" + clients.size());
				List<String> onlines = new ArrayList<String>();

				Set<String> keys = clients.keySet();
				Iterator<String> itKeys = keys.iterator();
				while (itKeys.hasNext()) {
					String key = itKeys.next();
					onlines.add(key);
				}

				mi.setOnlines(onlines);
				mi.setClientId(this.s.toString());

				// 转发消息给各个客户端
				itKeys = keys.iterator();
				while (itKeys.hasNext()) {
					String key = itKeys.next();
					RecvThread rt = clients.get(key);
					if (mi.isMsg()) { // 发送消息时不转发给自己
						if (rt != this) {
							rt.sendMsg(mi);
						}
					}
					else { // 获取在线用户列表。
						rt.sendMsg(mi);
					}
					System.out.println("转发消息给" + rt.user);
				}
			}

		}

		public void run() {
			while (isConnected) {
				try {

					// 读取信息
					MsgInfo mi = (MsgInfo) ois.readObject();
					// 激活连接
					if (!mi.isMsg()) { // 建立连接后发送一条空的信息，将用户名带到服务器。
						clients.put(mi.getSender(), this);
						user = mi.getSender();
						System.out.println(mi.getSender() + "已加入");
					}
					// 转发给客户端
					zfMsg(mi);

				} catch (IOException e) {
					// disconnect();
					disConnect();
					// e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		// 发送对象信息使用
		public void disConnect() {
			try {
				System.out.println("用户" + user
						+ "已离开");
				isConnected = false;
				if (ois != null)
					ois.close();
				if (oos != null)
					oos.close();
				if (s != null)
					s.close();
				clients.remove(this.user);
				// 一个客户端退出后，通知其他客户端
				MsgInfo mi = new MsgInfo();
				zfMsg(mi);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Server().start();
	}

}
