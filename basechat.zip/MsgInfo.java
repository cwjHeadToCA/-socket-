package basechat;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 包装发送的消息对象。
 *
 */
public class MsgInfo implements Serializable{
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2817564515497626133L;
	private String clientId; // 标示每个客户端
	// 私聊人
	private String user;
	// 是否私聊，设置USER时自动设置为TRUE，否则为FALSE。
	private boolean isSL = false;
	// 文件大小
	private int fileLen = -1;

	public int getFileLen() {
		return fileLen;
	}

	public void setFileLen(int fileLen) {
		this.fileLen = fileLen;
	}

	// 文件列表
	private String[] files = {};

	public String[] getFiles() {
		return files;
	}

	public void setFiles(String[] files) {
		this.files = files;
	}

	public boolean isSL() {
		return isSL;
	}

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
		isSL = true;
	}

	// 文本消息
	private String msgContent;
	// 图片消息
	private List<File> imgs = new ArrayList<File>();
	// 消息发送时间
	private Date sendTime;
	// 发送人
	private String sender;
	// online list
	private List<String> onlines = new ArrayList<String>();

	public List<String> getOnlines() {
		return onlines;
	}
	public void setOnlines(List<String> onlines) {
		this.onlines = onlines;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	// 一个客户端下线后通知其他客户端时，new一个空的消息对象。
	// 仅携带onlines，通知其他客户端更新任意列表
	public MsgInfo() {
		super();
	}
	public MsgInfo(String msgContent, List<File> imgs, List<File> attaches,
				   Date sendTime, String sender) {
		super();
		this.msgContent = msgContent;
		this.imgs = imgs;
		this.sendTime = sendTime;
		this.sender = sender;
	}
	// 私聊时用到这个构造方法。
	public MsgInfo(String msgContent, List<File> imgs, List<File> attaches,
				   Date sendTime, String sender,String user) {
		this(msgContent,imgs,attaches,sendTime,sender);
		this.user = user;
	}
	public MsgInfo(String msgContent) {
		this.msgContent = msgContent;
	}

	public String getMsgContent() {
		return msgContent;
	}
	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}
	public List<File> getImgs() {
		return imgs;
	}
	public void setImgs(List<File> imgs) {
		this.imgs = imgs;
	}
	public Date getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}

	public boolean isEmpty() {
		boolean a = msgContent == null || msgContent.equals("");
		boolean b = imgs == null || imgs.size() == 0;
		boolean d = files == null || files.length == 0;
		if (a && b && d) return true;
		return false;
	}

	public boolean isMsg() {
		if (isEmpty()) {
			if (sender != null && !"".equals(sender)) {
				return false;
			}
		}
		return true;
	}
}
